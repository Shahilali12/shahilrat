package willi.fiend.Ui

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import willi.fiend.R

val AppFont = FontFamily(Font(R.font.helvetica))